========================================================================
             ROMANTIC 3D GLOWING HEARTS UNIVERSE ❤️
========================================================================

How to run this project:

OPTION 1: (Easiest - Using VS Code / Live Server)
-------------------------------------------------
1. Unzip this folder.
2. Open the folder in VS Code.
3. Right-click on 'index.html' and select "Open with Live Server".

OPTION 2: (Using Node.js / Vite / Local Server)
-------------------------------------------------
1. Open terminal/command prompt inside this folder.
2. Run:
   npm install
   npm run dev
3. Open the localhost URL in any browser.

========================================================================
Enjoy the romantic glowing 3D universe! ✨
========================================================================
